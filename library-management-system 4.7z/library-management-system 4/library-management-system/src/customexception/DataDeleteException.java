package customexception;

public class DataDeleteException extends Exception{
    public DataDeleteException(String message){
        super(message);
    }
}
