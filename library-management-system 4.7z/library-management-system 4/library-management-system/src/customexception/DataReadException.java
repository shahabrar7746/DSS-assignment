package customexception;

public class DataReadException extends Exception {
    public  DataReadException(String message){
        super(message);
    }
}
