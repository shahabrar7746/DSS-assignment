package entity;

import enums.BookCategory;

public class Category {
    private String bookCategoryId;
    private BookCategory category;
    private long numberofBook;
    private Book book;
}
