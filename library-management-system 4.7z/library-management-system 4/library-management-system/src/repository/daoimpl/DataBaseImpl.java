package repository.daoimpl;

import repository.DataBase;

public abstract class DataBaseImpl implements DataBase {


}
