package server;

public interface LibraryServices {
    boolean add();

    boolean remove();

    boolean delete();

    void read();
}
