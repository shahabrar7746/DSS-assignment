package enums;

public enum Status {
    Borrowed,
    Returned,
}
