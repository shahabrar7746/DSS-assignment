package enums;

public enum BookCondition {
    good,
    damage,
}
