package enums;

public enum BookCategory {
    FICTION,
    NONFICTION,
    SCIENCE,
    HISTORY,
    ROMANCE,
    MYSTERY,
    FANTASY,
    CHILDREN,
    COOKING,
    ART,
    PHILOSOPHY,
    BIOGRAPHY,
    SELFHELP,
    PSYCHOLOGY,
    TRAVEL,
    SPORTS,
    MUSIC,
    POETRY,
    TRUECRIME,
    GRAPHIC,
    NOVELS,
    HUMOR
}
