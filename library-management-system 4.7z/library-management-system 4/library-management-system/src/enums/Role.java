package enums;

public enum Role {
    user,
    admin
}
