//package servicesImpl;
//
//import model.entity.Book;
//import enums.Role;
//import model.entity.User;
//
//import java.util.*;
//
//public abstract class Repository  {
//     static final String adminEmail = "admin@gmail.com";
//     static final String adminPassword = "1234";
//
//
//    //list of category database
//     static HashMap<String, List<Book>> bookCategoryDb;
//    //list of book database
//     static HashSet<Book> bookDb;
//    //list of user database
//     static HashMap<String, User> usersDb;
//    //list of borrow database
//   //  static HashMap<String, BookBorrowed> borrowDataDb = new HashMap<>();
//
//    //for load and initialize the admin in to  database
////    static {
////        usersDb = new HashMap<>();
////        User adminUser = new User("admin", adminEmail, adminPassword, Role.admin);
////        adminUser.setId("Super01");
////        usersDb.put(adminEmail, adminUser);
////    }
//
//
//    //admin remove user
//
//
//}
//
