package servicesImpl;

public class DataBaseServiceImpl {
}
