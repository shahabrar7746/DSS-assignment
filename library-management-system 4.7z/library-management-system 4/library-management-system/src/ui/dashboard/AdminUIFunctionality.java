//package ui.dashboard;
//
//import repository.daoimpl.BookDaoImpl;
//import entity.Book;
//import enums.BookCategory;
//import servicesImpl.BookServicesImpl;
//
//import java.util.Arrays;
//import java.util.InputMismatchException;
//import java.util.Scanner;
//
//import static ui.dashboard.UserFunctionality.dispalyCategoryEnumValue;
//
//public class AdminUIFunctionality {
//
//    static Scanner sc = new Scanner(System.in);
//
//    //BookDaoImpl bookDao = new BookDaoImpl();
//
//    //add book
//
//    //update book
//
//    public void updateBook(){
//
//    }
//
////    //display book
////    public void displayBook(){
////        new BookDaoImpl().read();
////    }
//
//}